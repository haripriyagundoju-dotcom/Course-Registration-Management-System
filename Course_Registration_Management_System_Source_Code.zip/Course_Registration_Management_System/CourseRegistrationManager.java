import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Course Registration Management System
 * Java Swing desktop application for viewing courses, registering students,
 * viewing registrations, and dropping a course.
 *
 * Note: This demonstration stores data in memory. Data is cleared when
 * the application is closed.
 */
public class CourseRegistrationManager extends JFrame {
    private final JTextField studentField = new JTextField(12);

    private final DefaultTableModel courseModel = new DefaultTableModel(
            new String[]{"Code", "Course Title", "Instructor", "Credits", "Seats"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final DefaultTableModel registrationModel = new DefaultTableModel(
            new String[]{"Student ID", "Course Code", "Course Title"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable courseTable = new JTable(courseModel);
    private final JTable registrationTable = new JTable(registrationModel);
    private final List<Course> courses = new ArrayList<>();
    private final List<Registration> registrations = new ArrayList<>();

    public CourseRegistrationManager() {
        setTitle("Course Registration Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        loadSampleCourses();

        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Student ID:"));
        topPanel.add(studentField);

        JButton registerButton = new JButton("Register");
        JButton viewButton = new JButton("View My Courses");
        JButton dropButton = new JButton("Drop Course");
        JButton clearButton = new JButton("Clear Fields");

        topPanel.add(registerButton);
        topPanel.add(viewButton);
        topPanel.add(dropButton);
        topPanel.add(clearButton);

        JPanel tablesPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        tablesPanel.add(new JScrollPane(courseTable));
        tablesPanel.add(new JScrollPane(registrationTable));

        add(topPanel, BorderLayout.NORTH);
        add(tablesPanel, BorderLayout.CENTER);

        refreshCourses();
        refreshRegistrations("");

        registerButton.addActionListener(e -> registerCourse());
        viewButton.addActionListener(e -> refreshRegistrations(studentField.getText().trim()));
        dropButton.addActionListener(e -> dropCourse());
        clearButton.addActionListener(e -> {
            studentField.setText("");
            courseTable.clearSelection();
            registrationTable.clearSelection();
            refreshRegistrations("");
        });
    }

    private void loadSampleCourses() {
        courses.add(new Course("CS201", "Object Oriented Programming", "Dr. Rao", 3, 30));
        courses.add(new Course("CS202", "Database Management Systems", "Dr. Kumar", 3, 25));
        courses.add(new Course("CS203", "Operating Systems", "Dr. Reddy", 4, 20));
        courses.add(new Course("CS204", "Computer Networks", "Dr. Sharma", 3, 18));
        courses.add(new Course("CS205", "Software Engineering", "Dr. Mehta", 3, 22));
    }

    private void registerCourse() {
        String studentId = studentField.getText().trim();
        int selectedRow = courseTable.getSelectedRow();

        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a student ID.");
            return;
        }

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Select a course from the course table.");
            return;
        }

        int modelRow = courseTable.convertRowIndexToModel(selectedRow);
        Course course = courses.get(modelRow);

        boolean alreadyRegistered = registrations.stream().anyMatch(registration ->
                registration.studentId.equals(studentId)
                        && registration.course.code.equals(course.code));

        if (alreadyRegistered) {
            JOptionPane.showMessageDialog(this, "You are already registered for this course.");
            return;
        }

        if (course.seats <= 0) {
            JOptionPane.showMessageDialog(this, "No seats are available for this course.");
            return;
        }

        registrations.add(new Registration(studentId, course));
        course.seats--;

        refreshCourses();
        refreshRegistrations(studentId);
        JOptionPane.showMessageDialog(this, "Registration successful.");
    }

    private void dropCourse() {
        String studentId = studentField.getText().trim();
        int selectedRow = registrationTable.getSelectedRow();

        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter your student ID first.");
            return;
        }

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Select a registered course to drop.");
            return;
        }

        int modelRow = registrationTable.convertRowIndexToModel(selectedRow);
        String selectedStudentId = registrationModel.getValueAt(modelRow, 0).toString();
        String selectedCourseCode = registrationModel.getValueAt(modelRow, 1).toString();

        if (!studentId.equals(selectedStudentId)) {
            JOptionPane.showMessageDialog(this, "The selected registration does not belong to this student ID.");
            return;
        }

        Registration target = null;
        for (Registration registration : registrations) {
            if (registration.studentId.equals(studentId)
                    && registration.course.code.equals(selectedCourseCode)) {
                target = registration;
                break;
            }
        }

        if (target == null) {
            JOptionPane.showMessageDialog(this, "Registration not found.");
            return;
        }

        registrations.remove(target);
        target.course.seats++;

        refreshCourses();
        refreshRegistrations(studentId);
        JOptionPane.showMessageDialog(this, "Course dropped successfully.");
    }

    private void refreshCourses() {
        courseModel.setRowCount(0);
        for (Course course : courses) {
            courseModel.addRow(new Object[]{
                    course.code, course.title, course.instructor, course.credits, course.seats
            });
        }
    }

    private void refreshRegistrations(String studentId) {
        registrationModel.setRowCount(0);
        if (studentId == null || studentId.isEmpty()) {
            return;
        }

        for (Registration registration : registrations) {
            if (registration.studentId.equals(studentId)) {
                registrationModel.addRow(new Object[]{
                        registration.studentId,
                        registration.course.code,
                        registration.course.title
                });
            }
        }
    }

    private static class Course {
        private final String code;
        private final String title;
        private final String instructor;
        private final int credits;
        private int seats;

        Course(String code, String title, String instructor, int credits, int seats) {
            this.code = code;
            this.title = title;
            this.instructor = instructor;
            this.credits = credits;
            this.seats = seats;
        }
    }

    private static class Registration {
        private final String studentId;
        private final Course course;

        Registration(String studentId, Course course) {
            this.studentId = studentId;
            this.course = course;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CourseRegistrationManager().setVisible(true));
    }
}
