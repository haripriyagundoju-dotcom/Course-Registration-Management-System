# Course Registration Management System

A Java Swing desktop application for a basic course-registration workflow.

## Features
- Display available courses with code, title, instructor, credits, and remaining seats
- Register a student for a selected course
- Prevent duplicate registration for the same course
- Check seat availability
- View courses registered by a student ID
- Drop a selected course and restore the available seat count
- Validate missing student IDs and missing selections

## Requirements
- Java Development Kit (JDK) 8 or later
- Any Java IDE (such as IntelliJ IDEA, Eclipse, or VS Code) or terminal

## Run from the terminal
1. Open a terminal in this folder.
2. Compile the program:

   ```bash
   javac CourseRegistrationManager.java
   ```

3. Run it:

   ```bash
   java CourseRegistrationManager
   ```

## How to use
1. Start the program.
2. Select a course from the top table.
3. Enter a student ID, such as `26885A50545`.
4. Click **Register**.
5. Click **View My Courses** to show registrations for that student ID.
6. Select a registration in the lower table and click **Drop Course** to remove it.

## Important limitation
This is a lab/demo implementation. Course and registration data are held in memory and are cleared when the application closes. It does not use a database, student authentication, or a real college course catalogue.
